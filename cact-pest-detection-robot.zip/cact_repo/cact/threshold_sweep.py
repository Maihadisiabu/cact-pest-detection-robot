"""
threshold_sweep.py
==================
Grid search over (tau_fav, tau_unfav) pairs on the validation set
to select optimal CACT thresholds.

Reproduces the threshold selection procedure described in Section 3.5
of the companion paper.

Usage
-----
python cact/threshold_sweep.py \
    --model  models/mobilenetv2_tomato_pest_edgetpu.tflite \
    --val-dir data/val/ \
    --env-log data/val/env_vectors.csv \
    --output  results/threshold_sweep.csv
"""

import argparse
import csv
import itertools
import logging
from pathlib import Path
from typing import List, Tuple

import numpy as np

from cact.cact_filter import CACTFilter
from vision.inference_coral import CoralInference

logging.basicConfig(level=logging.INFO, format='%(levelname)s %(message)s')
logger = logging.getLogger(__name__)

CLASS_NAMES = ['whitefly', 'aphid', 'thrips', 'no_pest']


def load_env_log(env_log_path: str) -> dict:
    """Load CSV of per-image environmental vectors keyed by image filename."""
    env_map = {}
    with open(env_log_path, newline='') as f:
        reader = csv.DictReader(f)
        for row in reader:
            env_map[row['filename']] = {
                'temperature': float(row['temperature']),
                'humidity':    float(row['humidity']),
                'lux':         float(row['lux']),
            }
    return env_map


def load_val_set(val_dir: str, env_map: dict) -> Tuple[List, List, List]:
    """
    Walk the validation directory tree and return:
      image_paths  : list of Path
      ground_truths: list of str (class name)
      env_vectors  : list of dict
    Expected structure:
      val_dir/
        whitefly/  img001.jpg ...
        aphid/     img002.jpg ...
        thrips/    img003.jpg ...
        no_pest/   img004.jpg ...
    """
    image_paths, ground_truths, env_vectors = [], [], []
    val_path = Path(val_dir)

    for class_dir in sorted(val_path.iterdir()):
        if not class_dir.is_dir():
            continue
        class_name = class_dir.name
        if class_name not in CLASS_NAMES:
            logger.warning("Skipping unknown class directory: %s", class_name)
            continue
        for img_path in sorted(class_dir.glob('*.jpg')):
            key = img_path.name
            if key not in env_map:
                logger.warning("No env vector for %s — skipping.", key)
                continue
            image_paths.append(img_path)
            ground_truths.append(class_name)
            env_vectors.append(env_map[key])

    logger.info("Loaded %d validation images.", len(image_paths))
    return image_paths, ground_truths, env_vectors


def compute_f1(y_true: List[str], y_pred: List[str]) -> float:
    """Macro-averaged F1 across pest classes only (excludes no_pest)."""
    pest_classes = ['whitefly', 'aphid', 'thrips']
    f1_scores = []
    for cls in pest_classes:
        tp = sum(1 for t, p in zip(y_true, y_pred) if t == cls and p == cls)
        fp = sum(1 for t, p in zip(y_true, y_pred) if t != cls and p == cls)
        fn = sum(1 for t, p in zip(y_true, y_pred) if t == cls and p != cls)
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        recall    = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        if (precision + recall) > 0:
            f1_scores.append(2 * precision * recall / (precision + recall))
        else:
            f1_scores.append(0.0)
    return float(np.mean(f1_scores))


def sweep(
    model: CoralInference,
    image_paths: List[Path],
    ground_truths: List[str],
    env_vectors: List[dict],
    tau_fav_range: List[float],
    tau_unfav_range: List[float],
) -> List[dict]:
    """Run the grid search and return results sorted by F1 descending."""

    # Pre-compute all softmax probability vectors (inference is the bottleneck)
    logger.info("Running inference on %d images...", len(image_paths))
    all_probs = [model.predict(str(p)) for p in image_paths]
    logger.info("Inference complete.")

    results = []
    for tau_fav, tau_unfav in itertools.product(tau_fav_range, tau_unfav_range):
        if tau_fav >= tau_unfav:
            continue  # Invalid combination

        cact = CACTFilter(tau_fav=tau_fav, tau_unfav=tau_unfav)
        predictions = []
        for probs, env in zip(all_probs, env_vectors):
            predicted_class, _ = cact.decide(probs, env)
            predictions.append(predicted_class)

        f1 = compute_f1(ground_truths, predictions)
        results.append({
            'tau_fav':   tau_fav,
            'tau_unfav': tau_unfav,
            'val_f1':    round(f1, 4),
        })

    results.sort(key=lambda x: x['val_f1'], reverse=True)
    return results


def main():
    parser = argparse.ArgumentParser(
        description='Grid search for optimal CACT thresholds on validation set.'
    )
    parser.add_argument('--model',   required=True, help='Path to .tflite model')
    parser.add_argument('--val-dir', required=True, help='Validation image directory')
    parser.add_argument('--env-log', required=True, help='CSV of per-image env vectors')
    parser.add_argument('--output',  default='results/threshold_sweep.csv')
    parser.add_argument(
        '--tau-fav-range',
        nargs='+', type=float,
        default=[0.40, 0.45, 0.50, 0.55, 0.60, 0.65, 0.70],
        help='tau_fav values to test'
    )
    parser.add_argument(
        '--tau-unfav-range',
        nargs='+', type=float,
        default=[0.70, 0.75, 0.80, 0.85, 0.90, 0.95],
        help='tau_unfav values to test'
    )
    args = parser.parse_args()

    model   = CoralInference(args.model)
    env_map = load_env_log(args.env_log)
    image_paths, ground_truths, env_vectors = load_val_set(args.val_dir, env_map)

    results = sweep(
        model, image_paths, ground_truths, env_vectors,
        args.tau_fav_range, args.tau_unfav_range,
    )

    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    with open(args.output, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['tau_fav', 'tau_unfav', 'val_f1'])
        writer.writeheader()
        writer.writerows(results)

    best = results[0]
    logger.info(
        "Best combination: tau_fav=%.2f, tau_unfav=%.2f → val F1=%.4f",
        best['tau_fav'], best['tau_unfav'], best['val_f1'],
    )
    logger.info("Full results saved to %s", args.output)


if __name__ == '__main__':
    main()
