"""
cact_filter.py
==============
Context-Aware Confidence Threshold (CACT) fusion algorithm.

Dynamically adjusts the CNN detection confidence threshold based on whether
current environmental conditions (temperature, humidity, illuminance) fall
within the biological favorability window for any target pest species.

Reference
---------
Maihadisi, A. R. (2026). Context-Aware IoT-CNN Fusion for False-Positive
Reduction in Edge-Based Agricultural Pest Detection: A Tropical Smallholder
Robot System. [Journal Name]. https://github.com/Maihadisiabu/cact-pest-detection-robot
"""

import logging
from typing import Dict, List, Optional, Tuple

from cact.favorability_windows import FAVORABILITY_WINDOWS, PestWindow

logger = logging.getLogger(__name__)


class CACTFilter:
    """
    Context-Aware Confidence Threshold filter.

    Parameters
    ----------
    tau_fav : float
        Detection threshold when environment is favourable for pests.
        Lower value → higher recall (fewer missed pests).
        Default: 0.55 (validated on Kaduna dry-season tomato dataset).

    tau_unfav : float
        Detection threshold when environment is unfavourable for pests.
        Higher value → higher precision (fewer false positives).
        Default: 0.85 (validated on Kaduna dry-season tomato dataset).

    windows : dict, optional
        Custom favorability windows. If None, uses built-in defaults
        from favorability_windows.py. Keys are pest class names; values
        are PestWindow namedtuples.

    class_names : list of str, optional
        Ordered list of class names matching CNN softmax output indices.
        Default: ['whitefly', 'aphid', 'thrips', 'no_pest']

    Examples
    --------
    >>> cact = CACTFilter(tau_fav=0.55, tau_unfav=0.85)
    >>> probs = [0.12, 0.08, 0.72, 0.08]   # softmax output
    >>> env   = {'temperature': 27.3, 'humidity': 68.0, 'lux': 520}
    >>> label, spray = cact.decide(probs, env)
    >>> print(label, spray)
    thrips True
    """

    CLASS_NAMES = ['whitefly', 'aphid', 'thrips', 'no_pest']

    def __init__(
        self,
        tau_fav: float = 0.55,
        tau_unfav: float = 0.85,
        windows: Optional[Dict[str, PestWindow]] = None,
        class_names: Optional[List[str]] = None,
    ):
        if not (0.0 < tau_fav < tau_unfav <= 1.0):
            raise ValueError(
                f"Thresholds must satisfy 0 < tau_fav < tau_unfav ≤ 1. "
                f"Got tau_fav={tau_fav}, tau_unfav={tau_unfav}."
            )

        self.tau_fav   = tau_fav
        self.tau_unfav = tau_unfav
        self.windows   = windows if windows is not None else FAVORABILITY_WINDOWS
        self.class_names = class_names if class_names is not None else self.CLASS_NAMES

        # Pre-compute set of pest class names (excludes 'no_pest')
        self._pest_classes = [c for c in self.class_names if c != 'no_pest']

        logger.info(
            "CACTFilter initialised | tau_fav=%.2f | tau_unfav=%.2f | "
            "pest classes=%s",
            self.tau_fav, self.tau_unfav, self._pest_classes,
        )

    # ------------------------------------------------------------------ #
    # Public API                                                           #
    # ------------------------------------------------------------------ #

    def is_favourable(self, env: Dict[str, float]) -> Tuple[bool, List[str]]:
        """
        Check whether current environmental conditions are biologically
        favourable for any target pest species.

        Parameters
        ----------
        env : dict
            Must contain keys 'temperature' (°C), 'humidity' (% RH),
            and 'lux' (lux).

        Returns
        -------
        favourable : bool
            True if ANY pest species' conditions are satisfied.
        active_pests : list of str
            Names of pest species whose favorability conditions are met.

        Raises
        ------
        KeyError
            If env is missing required keys.
        """
        self._validate_env(env)

        T = env['temperature']
        H = env['humidity']
        L = env['lux']

        active_pests = []
        for pest_name, w in self.windows.items():
            if pest_name not in self._pest_classes:
                continue
            t_ok = w.temp_min <= T <= w.temp_max
            h_ok = w.rh_min   <= H <= w.rh_max
            l_ok = L >= w.lux_min
            if t_ok and h_ok and l_ok:
                active_pests.append(pest_name)

        return bool(active_pests), active_pests

    def dynamic_threshold(self, env: Dict[str, float]) -> Tuple[float, bool]:
        """
        Compute the dynamic confidence threshold for the current environment.

        Returns
        -------
        threshold : float
            tau_fav if environment is favourable, tau_unfav otherwise.
        favourable : bool
            Whether the environment was flagged as favourable.
        """
        favourable, _ = self.is_favourable(env)
        threshold = self.tau_fav if favourable else self.tau_unfav
        return threshold, favourable

    def decide(
        self,
        probabilities: List[float],
        env: Dict[str, float],
    ) -> Tuple[str, bool]:
        """
        Make a final pest detection decision.

        Parameters
        ----------
        probabilities : list of float
            Softmax probabilities from the CNN, ordered to match
            self.class_names.
        env : dict
            Environmental readings with keys 'temperature', 'humidity', 'lux'.

        Returns
        -------
        predicted_class : str
            The class with the highest probability.
        spray : bool
            True if max probability exceeds the dynamic threshold AND
            the predicted class is a pest (not 'no_pest').
        """
        if len(probabilities) != len(self.class_names):
            raise ValueError(
                f"Expected {len(self.class_names)} probabilities, "
                f"got {len(probabilities)}."
            )

        max_prob  = max(probabilities)
        max_idx   = probabilities.index(max_prob)
        predicted = self.class_names[max_idx]

        threshold, favourable = self.dynamic_threshold(env)

        is_pest = predicted != 'no_pest'
        spray   = is_pest and (max_prob >= threshold)

        logger.debug(
            "CACT | class=%s | p=%.3f | tau=%.2f | fav=%s | spray=%s",
            predicted, max_prob, threshold, favourable, spray,
        )

        return predicted, spray

    def decide_with_detail(
        self,
        probabilities: List[float],
        env: Dict[str, float],
    ) -> dict:
        """
        Extended version of decide() returning a full diagnostic dict.
        Useful for logging, evaluation, and debugging.

        Returns
        -------
        dict with keys:
            predicted_class, max_prob, threshold, favourable,
            active_pests, spray, all_probs
        """
        self._validate_env(env)

        max_prob  = max(probabilities)
        max_idx   = probabilities.index(max_prob)
        predicted = self.class_names[max_idx]

        threshold, favourable = self.dynamic_threshold(env)
        _, active_pests = self.is_favourable(env)

        is_pest = predicted != 'no_pest'
        spray   = is_pest and (max_prob >= threshold)

        return {
            'predicted_class': predicted,
            'max_prob':        round(max_prob, 4),
            'threshold':       threshold,
            'favourable':      favourable,
            'active_pests':    active_pests,
            'spray':           spray,
            'all_probs':       {
                name: round(p, 4)
                for name, p in zip(self.class_names, probabilities)
            },
        }

    # ------------------------------------------------------------------ #
    # Private helpers                                                      #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _validate_env(env: Dict[str, float]) -> None:
        required = {'temperature', 'humidity', 'lux'}
        missing  = required - set(env.keys())
        if missing:
            raise KeyError(
                f"env dict is missing required keys: {missing}. "
                f"Expected keys: {required}."
            )
