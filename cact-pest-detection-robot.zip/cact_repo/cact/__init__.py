"""
cact — Context-Aware Confidence Threshold fusion package.

Modules
-------
cact_filter          : CACTFilter class (main API)
favorability_windows : Default biological favorability windows
threshold_sweep      : Validation-set grid search for threshold selection
"""

from cact.cact_filter import CACTFilter
from cact.favorability_windows import FAVORABILITY_WINDOWS, PestWindow, get_window

__all__ = ['CACTFilter', 'FAVORABILITY_WINDOWS', 'PestWindow', 'get_window']
__version__ = '1.0.0'
