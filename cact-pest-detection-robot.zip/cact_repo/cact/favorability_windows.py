"""
favorability_windows.py
=======================
Biological environmental favorability windows for target pest species.

Values are synthesised from peer-reviewed literature on pest activity
optima (see Supplementary Table S1 of the companion paper for full
source citations per numerical value).

Pest species covered
--------------------
- Bemisia tabaci      (whitefly)
- Aphis gossypii      (cotton/melon aphid)
- Frankliniella occidentalis  (western flower thrips)

Sources (selected)
------------------
- Shipp et al. (2003) Environ. Entomol. 32(6):1350-1356
- Navas-Castillo et al. (2011) Annu. Rev. Phytopathol. 49:219-248
- Blackman & Eastop (2000) Aphids on the World's Crops. Wiley.
- Lewis (1997) Thrips as Crop Pests. CAB International.
- Mound et al. (2022) Thysanoptera: Thrips as Crop Pests. CABI.
"""

from collections import namedtuple
from typing import Dict

# ── Data structure ──────────────────────────────────────────────────────────
PestWindow = namedtuple(
    'PestWindow',
    ['temp_min', 'temp_max', 'rh_min', 'rh_max', 'lux_min'],
)
"""
Biological activity favorability window for a pest species.

Fields
------
temp_min : float   Minimum temperature for active pest presence (°C)
temp_max : float   Maximum temperature for active pest presence (°C)
rh_min   : float   Minimum relative humidity (%)
rh_max   : float   Maximum relative humidity (%)
lux_min  : float   Minimum illuminance for pest activity (lux)

Note: No upper illuminance (lux_max) bound is applied for any of the
three species, as the reviewed literature does not report a quantified
upper field-activity boundary. Suppression at very high irradiance has
been noted anecdotally but no validated threshold was identified.
"""

# ── Default favorability windows ─────────────────────────────────────────────
FAVORABILITY_WINDOWS: Dict[str, PestWindow] = {

    'whitefly': PestWindow(
        temp_min=20.0,   # Navas-Castillo et al. (2011)
        temp_max=32.0,   # Shipp et al. (2003)
        rh_min=55.0,     # Shipp et al. (2003)
        rh_max=85.0,     # Shipp et al. (2003)
        lux_min=300.0,   # Synthesised from activity observation data
    ),

    'aphid': PestWindow(
        temp_min=15.0,   # Blackman & Eastop (2000)
        temp_max=30.0,   # Blackman & Eastop (2000)
        rh_min=50.0,     # Blackman & Eastop (2000)
        rh_max=90.0,     # Blackman & Eastop (2000)
        lux_min=200.0,   # Synthesised from activity observation data
    ),

    'thrips': PestWindow(
        temp_min=18.0,   # Mound et al. (2022); Lewis (1997)
        temp_max=35.0,   # Mound et al. (2022)
        rh_min=60.0,     # Lewis (1997)
        rh_max=90.0,     # Lewis (1997)
        lux_min=400.0,   # Synthesised from activity observation data
    ),
}


def get_window(pest_name: str) -> PestWindow:
    """
    Retrieve the favorability window for a named pest.

    Parameters
    ----------
    pest_name : str
        One of 'whitefly', 'aphid', 'thrips'.

    Returns
    -------
    PestWindow

    Raises
    ------
    KeyError if pest_name is not recognised.
    """
    if pest_name not in FAVORABILITY_WINDOWS:
        raise KeyError(
            f"Unknown pest '{pest_name}'. "
            f"Available: {list(FAVORABILITY_WINDOWS.keys())}"
        )
    return FAVORABILITY_WINDOWS[pest_name]


def add_custom_window(pest_name: str, window: PestWindow) -> None:
    """
    Register a custom favorability window, e.g. for a new pest species
    or locally calibrated thresholds.

    Parameters
    ----------
    pest_name : str   Unique identifier for the pest.
    window    : PestWindow
    """
    FAVORABILITY_WINDOWS[pest_name] = window
