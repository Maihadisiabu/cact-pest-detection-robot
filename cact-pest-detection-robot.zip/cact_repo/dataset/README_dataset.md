# Dataset — CACT Tomato Pest Proxy Dataset

## Overview

This dataset was created to train and evaluate the CACT pest detection system described in:

> Maihadisi, A. R. (2026). Context-Aware IoT–CNN Fusion for False-Positive Reduction in Edge-Based Agricultural Pest Detection: A Tropical Smallholder Robot System. *Computers and Electronics in Agriculture*.

**Important note:** All images in this dataset use artificial pest decoys (life-size, high-resolution photographic prints on matte paper) attached to real tomato plant leaves, not live insects. This is a controlled proxy evaluation dataset. See the companion paper for full discussion of this methodological choice.

---

## Dataset Details

| Property | Value |
|---|---|
| Total images | 3,000 |
| Classes | 4 (whitefly, aphid, thrips, no_pest) |
| Image resolution | 224 × 224 px (cropped from 1280 × 720 captures) |
| Camera | Raspberry Pi Camera Module v2 (8 MP) |
| Lighting conditions | Morning (07:30–09:00) and Evening (16:30–18:00) |
| Collection site | Chikun LGA, Kaduna State, Nigeria (10.52°N, 7.44°E) |
| Collection period | October–December 2025 (dry season) |
| Sensor logging | DHT22 + BH1750 readings linked per image |

## Class Distribution

| Class | Count | % | Test set (n=450) |
|---|---|---|---|
| no_pest | 1,200 | 40% | 150 |
| whitefly | 750 | 25% | 120 |
| aphid | 600 | 20% | 100 |
| thrips | 450 | 15% | 80 |

## Train / Val / Test Split

Stratified by class and lighting condition:

| Split | Images | % |
|---|---|---|
| Train | 2,100 | 70% |
| Validation | 450 | 15% |
| Test | 450 | 15% |

## Directory Structure

```
dataset/
  train/
    whitefly/    *.jpg   (525 images)
    aphid/       *.jpg   (420 images)
    thrips/      *.jpg   (315 images)
    no_pest/     *.jpg   (840 images)
  val/
    whitefly/    *.jpg   (113 images)
    aphid/       *.jpg   (90 images)
    thrips/      *.jpg   (68 images)
    no_pest/     *.jpg   (180 images)
  test/
    whitefly/    *.jpg   (120 images)
    aphid/       *.jpg   (100 images)
    thrips/      *.jpg   (80 images)
    no_pest/     *.jpg   (150 images)
  env_vectors/
    train_env.csv        # Environmental readings per training image
    val_env.csv          # Environmental readings per validation image
    test_env.csv         # Environmental readings per test image
```

## Environmental Vector CSV Format

Each CSV file (`train_env.csv`, `val_env.csv`, `test_env.csv`) has the following columns:

| Column | Type | Description |
|---|---|---|
| `filename` | string | Image filename (e.g., `img_0001.jpg`) |
| `temperature` | float | Air temperature in °C (DHT22) |
| `humidity` | float | Relative humidity in % (DHT22) |
| `lux` | float | Illuminance in lux (BH1750) |
| `lighting_condition` | string | `morning` or `evening` |
| `class_label` | string | Ground truth class |

Example:
```
filename,temperature,humidity,lux,lighting_condition,class_label
img_0001.jpg,27.3,68.0,843,morning,whitefly
img_0002.jpg,27.5,67.8,851,morning,no_pest
img_0003.jpg,31.2,61.4,2140,evening,aphid
```

## Download

The dataset is archived on Zenodo alongside the code:

**https://doi.org/10.5281/zenodo.20410537**

## Labelling Protocol

1. Images were captured by the onboard camera at 0.3–1.0 m from the leaf surface.
2. Artificial pest decoys were attached to leaf undersides (whitefly, thrips) and upper surfaces (aphid) by hand.
3. Labels were assigned manually by visual inspection of each image.
4. All labels were independently verified by a second reviewer; disagreements were resolved by consensus.
5. Images with ambiguous or partially occluded decoys were discarded.

## Augmentation (applied during training only)

- Random horizontal flip
- Random rotation ±20°
- Random brightness ±0.3
- Random contrast ±0.2
- Random saturation ±0.2
- Random hue ±0.05

## Licence

This dataset is released under the **Creative Commons Attribution 4.0 International (CC BY 4.0)** licence.
You are free to share and adapt the data for any purpose, provided appropriate credit is given.

## Citation

If you use this dataset, please cite the companion paper:

```bibtex
@article{maihadisi2026cact,
  title   = {Context-Aware {IoT}--{CNN} Fusion for False-Positive Reduction in
             Edge-Based Agricultural Pest Detection: A Tropical Smallholder Robot System},
  author  = {Maihadisi, Abubakar Rabiu},
  journal = {Computers and Electronics in Agriculture},
  year    = {2026},
  doi     = {[To be assigned upon acceptance]},
  url     = {https://github.com/Maihadisiabu/cact-pest-detection-robot}
}
```
