/*
 * sensor_publisher.ino
 * ====================
 * ESP32 firmware: reads DHT22 (temperature + humidity) and BH1750
 * (illuminance) sensors, and publishes JSON payloads to the Raspberry Pi
 * via MQTT at 0.5 Hz (every 2 seconds).
 *
 * Hardware connections
 * --------------------
 *   DHT22 DATA pin  → GPIO 4
 *   BH1750 SDA      → GPIO 21
 *   BH1750 SCL      → GPIO 22
 *   (VCC → 3.3 V, GND → GND for both sensors)
 *
 * Required libraries (install via Arduino Library Manager)
 * ---------------------------------------------------------
 *   - DHT sensor library (Adafruit)
 *   - Adafruit Unified Sensor
 *   - BH1750 (by Christopher Laws)
 *   - PubSubClient (by Nick O'Leary)
 *   - WiFi (built-in ESP32 core)
 *
 * MQTT topic: pest_robot/sensors
 * Payload format (JSON):
 *   {
 *     "temperature": 27.3,
 *     "humidity":    68.0,
 *     "lux":         520.0,
 *     "soil_moisture": 42.1
 *   }
 *
 * Configuration
 * -------------
 *   Update WIFI_SSID, WIFI_PASSWORD, and MQTT_SERVER below.
 *   MQTT_SERVER should be the IP address of the Raspberry Pi running
 *   the Mosquitto broker (e.g., "192.168.1.100").
 */

#include <WiFi.h>
#include <PubSubClient.h>
#include <DHT.h>
#include <Wire.h>
#include <BH1750.h>
#include <ArduinoJson.h>

// ── User configuration ─────────────────────────────────────────────────────
const char* WIFI_SSID      = "YOUR_WIFI_SSID";       // <-- SET THIS
const char* WIFI_PASSWORD  = "YOUR_WIFI_PASSWORD";    // <-- SET THIS
const char* MQTT_SERVER    = "192.168.1.100";         // <-- SET TO RPi IP
const int   MQTT_PORT      = 1883;
const char* MQTT_TOPIC     = "pest_robot/sensors";
const char* CLIENT_ID      = "esp32_sensor_node";

// ── Pin definitions ────────────────────────────────────────────────────────
#define DHT_PIN       4
#define DHT_TYPE      DHT22
#define SOIL_ADC_PIN  34     // Capacitive soil moisture sensor (ADC1)

// ── Publish interval ───────────────────────────────────────────────────────
const unsigned long PUBLISH_INTERVAL_MS = 2000;   // 0.5 Hz

// ── Sensor objects ─────────────────────────────────────────────────────────
DHT    dht(DHT_PIN, DHT_TYPE);
BH1750 lightMeter;

// ── Network objects ────────────────────────────────────────────────────────
WiFiClient   wifiClient;
PubSubClient mqttClient(wifiClient);

// ── State ──────────────────────────────────────────────────────────────────
unsigned long lastPublishTime = 0;


// ── Setup ──────────────────────────────────────────────────────────────────
void setup() {
  Serial.begin(115200);
  delay(500);
  Serial.println("\n[CACT Sensor Node] Booting...");

  // Initialise I2C for BH1750
  Wire.begin(21, 22);
  if (!lightMeter.begin(BH1750::CONTINUOUS_HIGH_RES_MODE)) {
    Serial.println("[ERROR] BH1750 not found. Check wiring.");
  } else {
    Serial.println("[OK] BH1750 ready.");
  }

  // Initialise DHT22
  dht.begin();
  Serial.println("[OK] DHT22 ready.");

  // Configure soil moisture pin
  pinMode(SOIL_ADC_PIN, INPUT);

  // Connect to WiFi
  connectWiFi();

  // Configure MQTT
  mqttClient.setServer(MQTT_SERVER, MQTT_PORT);
  mqttClient.setKeepAlive(60);
  connectMQTT();

  Serial.println("[OK] Setup complete. Publishing at 0.5 Hz.");
}


// ── Main loop ──────────────────────────────────────────────────────────────
void loop() {
  // Maintain MQTT connection
  if (!mqttClient.connected()) {
    connectMQTT();
  }
  mqttClient.loop();

  // Publish sensor data at 0.5 Hz
  unsigned long now = millis();
  if (now - lastPublishTime >= PUBLISH_INTERVAL_MS) {
    lastPublishTime = now;
    publishSensorData();
  }
}


// ── Sensor reading & publishing ────────────────────────────────────────────
void publishSensorData() {
  // Read DHT22
  float temperature = dht.readTemperature();   // °C
  float humidity    = dht.readHumidity();      // %

  if (isnan(temperature) || isnan(humidity)) {
    Serial.println("[WARN] DHT22 read failed — skipping publish.");
    return;
  }

  // Read BH1750
  float lux = lightMeter.readLightLevel();
  if (lux < 0) {
    lux = 0.0;   // BH1750 returns -1 on error
  }

  // Read soil moisture (raw ADC 0–4095 → 0–100%)
  int   soilRaw      = analogRead(SOIL_ADC_PIN);
  float soilMoisture = map(soilRaw, 4095, 1500, 0, 100);  // calibrate range!
  soilMoisture       = constrain(soilMoisture, 0.0, 100.0);

  // Build JSON payload
  StaticJsonDocument<200> doc;
  doc["temperature"]   = round(temperature * 10.0) / 10.0;
  doc["humidity"]      = round(humidity    * 10.0) / 10.0;
  doc["lux"]           = round(lux);
  doc["soil_moisture"] = round(soilMoisture * 10.0) / 10.0;

  char payload[200];
  serializeJson(doc, payload);

  // Publish
  bool ok = mqttClient.publish(MQTT_TOPIC, payload, /*retained=*/false);
  if (ok) {
    Serial.printf("[PUB] T=%.1f°C H=%.1f%% Lux=%.0f Soil=%.1f%%\n",
                  temperature, humidity, lux, soilMoisture);
  } else {
    Serial.println("[WARN] MQTT publish failed.");
  }
}


// ── WiFi connection ────────────────────────────────────────────────────────
void connectWiFi() {
  Serial.printf("[WiFi] Connecting to '%s'", WIFI_SSID);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 20) {
    delay(500);
    Serial.print(".");
    attempts++;
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.printf("\n[WiFi] Connected! IP: %s\n", WiFi.localIP().toString().c_str());
  } else {
    Serial.println("\n[ERROR] WiFi connection failed. Restarting...");
    ESP.restart();
  }
}


// ── MQTT connection ────────────────────────────────────────────────────────
void connectMQTT() {
  int attempts = 0;
  while (!mqttClient.connected() && attempts < 5) {
    Serial.printf("[MQTT] Connecting to %s:%d...", MQTT_SERVER, MQTT_PORT);
    if (mqttClient.connect(CLIENT_ID)) {
      Serial.println(" connected.");
    } else {
      Serial.printf(" failed (state=%d). Retrying in 2 s.\n",
                    mqttClient.state());
      delay(2000);
      attempts++;
    }
  }
  if (!mqttClient.connected()) {
    Serial.println("[ERROR] MQTT connection failed after retries. Restarting...");
    ESP.restart();
  }
}
