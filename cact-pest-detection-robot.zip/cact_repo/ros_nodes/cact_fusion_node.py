#!/usr/bin/env python3
"""
cact_fusion_node.py
===================
ROS Melodic node: implements the Context-Aware Confidence Threshold (CACT)
fusion algorithm. Subscribes to CNN probabilities and IoT sensor readings,
applies the dynamic threshold decision, and publishes a binary spray command.

This is the central contribution of the CACT system — all fusion logic
lives here.

Subscriptions :
    /pest_detection/probabilities  (std_msgs/Float32MultiArray)
        Softmax probabilities from vision_node
    /iot/environment               (std_msgs/Float32MultiArray)
        [temperature, humidity, lux, soil_moisture] from iot_node

Publications  :
    /spray/command                 (std_msgs/Bool)
        True = activate sprayer, False = do not spray
    /spray/diagnosis               (std_msgs/String)
        JSON diagnostic string (class, prob, threshold, fav, spray)

Parameters (ROS param server)
------------------------------
    ~tau_fav      : float  CACT favourable threshold (default: 0.55)
    ~tau_unfav    : float  CACT unfavourable threshold (default: 0.85)
    ~env_timeout  : float  Max age of env reading before refusing to spray (default: 3.0 s)
"""

import json
import math
import threading
import time

import rospy
from std_msgs.msg import Bool, Float32MultiArray, String

from cact.cact_filter import CACTFilter

CLASS_NAMES = ['whitefly', 'aphid', 'thrips', 'no_pest']


class CACTFusionNode:

    def __init__(self):
        rospy.init_node('cact_fusion_node', anonymous=False)

        tau_fav      = rospy.get_param('~tau_fav',     0.55)
        tau_unfav    = rospy.get_param('~tau_unfav',   0.85)
        self.env_timeout = rospy.get_param('~env_timeout', 3.0)

        self._cact = CACTFilter(tau_fav=tau_fav, tau_unfav=tau_unfav)

        # Shared state (thread-safe)
        self._lock     = threading.Lock()
        self._env      = None     # latest env dict
        self._env_ts   = None     # timestamp of last env update

        # ── Publishers ────────────────────────────────────────────────────
        self.pub_spray = rospy.Publisher('/spray/command',   Bool,   queue_size=1)
        self.pub_diag  = rospy.Publisher('/spray/diagnosis', String, queue_size=1)

        # ── Subscribers ───────────────────────────────────────────────────
        rospy.Subscriber(
            '/pest_detection/probabilities',
            Float32MultiArray,
            self._cb_probs,
            queue_size=1,
        )
        rospy.Subscriber(
            '/iot/environment',
            Float32MultiArray,
            self._cb_env,
            queue_size=1,
        )

        rospy.loginfo(
            "CACTFusionNode ready | tau_fav=%.2f | tau_unfav=%.2f",
            tau_fav, tau_unfav,
        )

    # ── Callbacks ─────────────────────────────────────────────────────────────

    def _cb_env(self, msg: Float32MultiArray):
        """Cache the latest environmental reading with a timestamp."""
        data = list(msg.data)
        if len(data) < 3:
            rospy.logwarn("Received malformed environment message (len=%d).", len(data))
            return

        # Guard against NaN from ESP32 (sensor not yet initialised)
        if any(math.isnan(v) for v in data[:3]):
            rospy.logwarn_throttle(5.0, "NaN in env reading — skipping CACT update.")
            return

        with self._lock:
            self._env = {
                'temperature': data[0],
                'humidity':    data[1],
                'lux':         data[2],
            }
            self._env_ts = time.time()

    def _cb_probs(self, msg: Float32MultiArray):
        """
        Called on every new CNN probability vector.
        Runs the CACT decision and publishes the spray command.
        """
        probs = list(msg.data)
        if len(probs) != len(CLASS_NAMES):
            rospy.logwarn(
                "Unexpected probability vector length: %d (expected %d).",
                len(probs), len(CLASS_NAMES),
            )
            return

        with self._lock:
            env    = self._env
            env_ts = self._env_ts

        # ── Safety check: refuse to spray if env data is missing or stale ──
        if env is None:
            rospy.logwarn_throttle(5.0,
                "No IoT env data received yet — defaulting to NO SPRAY."
            )
            self._publish(spray=False, probs=probs, env=None, detail={})
            return

        age = time.time() - env_ts
        if age > self.env_timeout:
            rospy.logwarn_throttle(2.0,
                "Env data is %.1f s old (timeout=%.1f s) — defaulting to NO SPRAY.",
                age, self.env_timeout,
            )
            self._publish(spray=False, probs=probs, env=env, detail={})
            return

        # ── CACT decision ─────────────────────────────────────────────────
        detail = self._cact.decide_with_detail(probs, env)
        spray  = detail['spray']

        self._publish(spray=spray, probs=probs, env=env, detail=detail)

    def _publish(self, spray: bool, probs: list, env: dict, detail: dict):
        """Publish spray command and diagnostic message."""
        self.pub_spray.publish(Bool(data=spray))

        diag = {
            'spray':           spray,
            'predicted_class': detail.get('predicted_class', 'unknown'),
            'max_prob':        round(max(probs), 4) if probs else None,
            'threshold':       detail.get('threshold'),
            'favourable':      detail.get('favourable'),
            'active_pests':    detail.get('active_pests', []),
            'env':             env,
            'timestamp':       time.time(),
        }
        self.pub_diag.publish(String(data=json.dumps(diag)))

        if spray:
            rospy.loginfo(
                "SPRAY | class=%s | p=%.3f | tau=%.2f | fav=%s",
                detail.get('predicted_class'), detail.get('max_prob'),
                detail.get('threshold', 0), detail.get('favourable'),
            )

    def spin(self):
        rospy.spin()


if __name__ == '__main__':
    try:
        node = CACTFusionNode()
        node.spin()
    except rospy.ROSInterruptException:
        pass
