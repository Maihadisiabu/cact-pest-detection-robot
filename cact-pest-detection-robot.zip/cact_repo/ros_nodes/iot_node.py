#!/usr/bin/env python3
"""
iot_node.py
===========
ROS Melodic node: subscribes to environmental sensor readings published
by the ESP32 via MQTT (Mosquitto broker running on the Raspberry Pi)
and re-publishes them as a ROS topic for consumption by the CACT node.

The ESP32 publishes JSON payloads at 0.5 Hz to:
    Topic: pest_robot/sensors
    Payload: {"temperature": 27.3, "humidity": 68.0, "lux": 520.0, "soil_moisture": 42.1}

Subscriptions : none (MQTT, not ROS)
Publications  :
    /iot/environment  (std_msgs/Float32MultiArray)
        [temperature_C, humidity_pct, lux, soil_moisture_pct]

Parameters (ROS param server)
------------------------------
    ~mqtt_host      : str   MQTT broker hostname (default: 'localhost')
    ~mqtt_port      : int   MQTT broker port (default: 1883)
    ~mqtt_topic     : str   MQTT topic to subscribe (default: 'pest_robot/sensors')
    ~timeout_sec    : float Stale reading age before warning (default: 5.0)
"""

import json
import time
import threading

import paho.mqtt.client as mqtt
import rospy
from std_msgs.msg import Float32MultiArray, MultiArrayDimension

# Sentinel representing "no reading received yet"
_NO_DATA = float('nan')


class IoTNode:

    FIELDS = ['temperature', 'humidity', 'lux', 'soil_moisture']

    def __init__(self):
        rospy.init_node('iot_node', anonymous=False)

        self.mqtt_host  = rospy.get_param('~mqtt_host',  'localhost')
        self.mqtt_port  = rospy.get_param('~mqtt_port',   1883)
        self.mqtt_topic = rospy.get_param('~mqtt_topic', 'pest_robot/sensors')
        self.timeout    = rospy.get_param('~timeout_sec', 5.0)

        self._lock        = threading.Lock()
        self._last_values = {f: _NO_DATA for f in self.FIELDS}
        self._last_ts     = None

        # ── Publisher ─────────────────────────────────────────────────────
        self.pub = rospy.Publisher(
            '/iot/environment',
            Float32MultiArray, queue_size=1,
        )

        # ── MQTT client ───────────────────────────────────────────────────
        self._client = mqtt.Client(client_id='ros_iot_node')
        self._client.on_connect = self._on_connect
        self._client.on_message = self._on_message
        self._client.on_disconnect = self._on_disconnect

        rospy.loginfo(
            "IoTNode connecting to MQTT broker at %s:%d (topic: %s)",
            self.mqtt_host, self.mqtt_port, self.mqtt_topic,
        )
        self._client.connect(self.mqtt_host, self.mqtt_port, keepalive=60)
        self._client.loop_start()

        rospy.loginfo("IoTNode ready.")

    # ── MQTT callbacks ────────────────────────────────────────────────────────

    def _on_connect(self, client, userdata, flags, rc):
        if rc == 0:
            rospy.loginfo("MQTT connected. Subscribing to '%s'.", self.mqtt_topic)
            client.subscribe(self.mqtt_topic)
        else:
            rospy.logerr("MQTT connection failed with code %d.", rc)

    def _on_disconnect(self, client, userdata, rc):
        if rc != 0:
            rospy.logwarn("MQTT disconnected unexpectedly (rc=%d). Reconnecting...", rc)

    def _on_message(self, client, userdata, msg):
        try:
            payload = json.loads(msg.payload.decode('utf-8'))
        except (json.JSONDecodeError, UnicodeDecodeError) as e:
            rospy.logwarn("Failed to parse MQTT payload: %s", e)
            return

        with self._lock:
            for field in self.FIELDS:
                if field in payload:
                    self._last_values[field] = float(payload[field])
            self._last_ts = time.time()

    # ── ROS publishing ────────────────────────────────────────────────────────

    def _build_message(self) -> Float32MultiArray:
        with self._lock:
            values = [self._last_values[f] for f in self.FIELDS]
            ts     = self._last_ts

        if ts is None:
            rospy.logwarn_throttle(10.0, "No sensor data received yet.")
        elif (time.time() - ts) > self.timeout:
            rospy.logwarn_throttle(5.0,
                "Sensor data is stale (%.1f s old). Check ESP32 connection.",
                time.time() - ts,
            )

        msg = Float32MultiArray()
        msg.layout.dim = [
            MultiArrayDimension(
                label=','.join(self.FIELDS),
                size=len(values),
                stride=len(values),
            )
        ]
        msg.data = values
        return msg

    def run(self):
        # Publish at the same rate the ESP32 updates (0.5 Hz)
        rate = rospy.Rate(0.5)
        while not rospy.is_shutdown():
            self.pub.publish(self._build_message())
            rate.sleep()

        self._client.loop_stop()
        self._client.disconnect()
        rospy.loginfo("IoTNode shut down.")


if __name__ == '__main__':
    try:
        node = IoTNode()
        node.run()
    except rospy.ROSInterruptException:
        pass
