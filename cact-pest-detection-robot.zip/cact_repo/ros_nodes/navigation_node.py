#!/usr/bin/env python3
"""
navigation_node.py
==================
ROS Melodic node: handles robot navigation and spray actuation.

Responsibilities
----------------
1. A* path planning over a pre-defined field row grid with GPS waypoints.
2. Obstacle avoidance using four HC-SR04 ultrasonic sensors (front,
   left, right, rear).
3. Subscribing to /spray/command and activating the servo-nozzle
   when a pest detection is confirmed by the CACT node.
4. Publishing robot status and odometry.

Subscriptions :
    /spray/command   (std_msgs/Bool)       From cact_fusion_node
    /gps/fix         (sensor_msgs/NavSatFix) From GPS module (u-blox NEO-6M)

Publications  :
    /cmd_vel         (geometry_msgs/Twist)  Motor velocity commands
    /robot/status    (std_msgs/String)      JSON status string

Hardware
--------
    GPIO 17, 27, 22, 5  → L298N motor driver IN pins
    GPIO 18             → Servo PWM (sprayer nozzle)
    GPIO 23,24 (trig/echo) × 4  → HC-SR04 sensors

Parameters (ROS param server)
------------------------------
    ~traverse_speed    : float  Forward speed m/s (default: 0.08)
    ~obstacle_dist_m   : float  Stop distance for obstacle (default: 0.50)
    ~spray_duration_s  : float  Nozzle open time per activation (default: 0.5)
    ~row_spacing_m     : float  Distance between tomato rows (default: 0.6)
    ~waypoints_file    : str    Path to YAML waypoints file
"""

import json
import math
import time
import heapq
import threading

import rospy
from std_msgs.msg import Bool, String
from geometry_msgs.msg import Twist

try:
    from sensor_msgs.msg import NavSatFix
    GPS_AVAILABLE = True
except ImportError:
    GPS_AVAILABLE = False

try:
    import RPi.GPIO as GPIO
    GPIO_AVAILABLE = True
except (ImportError, RuntimeError):
    GPIO_AVAILABLE = False
    rospy.logwarn("RPi.GPIO not available — running in simulation mode.")


# ── GPIO pin assignments ──────────────────────────────────────────────────────
MOTOR_PINS = {
    'front_left_fwd':  17,
    'front_left_rev':  27,
    'front_right_fwd': 22,
    'front_right_rev':  5,
    'rear_left_fwd':   6,
    'rear_left_rev':   13,
    'rear_right_fwd':  19,
    'rear_right_rev':  26,
}
SPRAY_SERVO_PIN = 18

ULTRASONIC = {
    'front': {'trig': 23, 'echo': 24},
    'left':  {'trig': 25, 'echo':  8},
    'right': {'trig': 7,  'echo': 12},
    'rear':  {'trig': 16, 'echo': 20},
}


class GPIOController:
    """Low-level GPIO motor and servo control."""

    def __init__(self):
        if not GPIO_AVAILABLE:
            return
        GPIO.setmode(GPIO.BCM)
        GPIO.setwarnings(False)

        for pin in MOTOR_PINS.values():
            GPIO.setup(pin, GPIO.OUT)
            GPIO.output(pin, GPIO.LOW)

        GPIO.setup(SPRAY_SERVO_PIN, GPIO.OUT)
        self._servo_pwm = GPIO.PWM(SPRAY_SERVO_PIN, 50)  # 50 Hz servo
        self._servo_pwm.start(7.5)   # neutral / closed position

        for sensor in ULTRASONIC.values():
            GPIO.setup(sensor['trig'], GPIO.OUT)
            GPIO.setup(sensor['echo'], GPIO.IN)
            GPIO.output(sensor['trig'], GPIO.LOW)

        time.sleep(0.1)

    def set_motors(self, left_fwd: bool, right_fwd: bool, speed: float = 1.0):
        if not GPIO_AVAILABLE:
            return
        GPIO.output(MOTOR_PINS['front_left_fwd'],  GPIO.HIGH if left_fwd  else GPIO.LOW)
        GPIO.output(MOTOR_PINS['front_left_rev'],  GPIO.LOW  if left_fwd  else GPIO.HIGH)
        GPIO.output(MOTOR_PINS['rear_left_fwd'],   GPIO.HIGH if left_fwd  else GPIO.LOW)
        GPIO.output(MOTOR_PINS['rear_left_rev'],   GPIO.LOW  if left_fwd  else GPIO.HIGH)
        GPIO.output(MOTOR_PINS['front_right_fwd'], GPIO.HIGH if right_fwd else GPIO.LOW)
        GPIO.output(MOTOR_PINS['front_right_rev'], GPIO.LOW  if right_fwd else GPIO.HIGH)
        GPIO.output(MOTOR_PINS['rear_right_fwd'],  GPIO.HIGH if right_fwd else GPIO.LOW)
        GPIO.output(MOTOR_PINS['rear_right_rev'],  GPIO.LOW  if right_fwd else GPIO.HIGH)

    def stop_motors(self):
        if not GPIO_AVAILABLE:
            return
        for pin in MOTOR_PINS.values():
            GPIO.output(pin, GPIO.LOW)

    def activate_sprayer(self, duration_s: float = 0.5):
        """Open servo nozzle for duration_s seconds, then close."""
        if not GPIO_AVAILABLE:
            rospy.loginfo("[SIM] Sprayer activated for %.2f s", duration_s)
            return
        self._servo_pwm.ChangeDutyCycle(10.0)  # open (~90°)
        time.sleep(duration_s)
        self._servo_pwm.ChangeDutyCycle(7.5)   # closed (0°)

    def read_ultrasonic(self, direction: str) -> float:
        """
        Measure distance (metres) from ultrasonic sensor.
        Returns float('inf') on timeout.
        """
        if not GPIO_AVAILABLE:
            return float('inf')

        trig = ULTRASONIC[direction]['trig']
        echo = ULTRASONIC[direction]['echo']

        GPIO.output(trig, GPIO.HIGH)
        time.sleep(0.00001)
        GPIO.output(trig, GPIO.LOW)

        timeout = time.time() + 0.04   # 40 ms max wait
        while GPIO.input(echo) == 0:
            if time.time() > timeout:
                return float('inf')
        t_start = time.time()

        while GPIO.input(echo) == 1:
            if time.time() > timeout:
                return float('inf')
        t_end = time.time()

        distance_m = (t_end - t_start) * 340.0 / 2.0
        return round(distance_m, 3)

    def cleanup(self):
        if GPIO_AVAILABLE:
            self._servo_pwm.stop()
            self.stop_motors()
            GPIO.cleanup()


# ── A* path planner ───────────────────────────────────────────────────────────

def astar(grid, start, goal):
    """
    A* search on a 2-D boolean grid.

    Parameters
    ----------
    grid  : list of list of bool   True = traversable, False = obstacle
    start : tuple (row, col)
    goal  : tuple (row, col)

    Returns
    -------
    list of (row, col) tuples (path including start and goal),
    or empty list if no path found.
    """
    rows, cols = len(grid), len(grid[0])

    def h(a, b):
        return abs(a[0] - b[0]) + abs(a[1] - b[1])

    open_set = []
    heapq.heappush(open_set, (h(start, goal), 0, start))
    came_from = {}
    g_score = {start: 0}

    while open_set:
        _, g, current = heapq.heappop(open_set)

        if current == goal:
            path = []
            while current in came_from:
                path.append(current)
                current = came_from[current]
            path.append(start)
            return list(reversed(path))

        r, c = current
        for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            nr, nc = r + dr, c + dc
            if 0 <= nr < rows and 0 <= nc < cols and grid[nr][nc]:
                new_g = g + 1
                nb = (nr, nc)
                if new_g < g_score.get(nb, float('inf')):
                    g_score[nb] = new_g
                    came_from[nb] = current
                    f = new_g + h(nb, goal)
                    heapq.heappush(open_set, (f, new_g, nb))

    return []   # no path found


# ── Navigation node ───────────────────────────────────────────────────────────

class NavigationNode:

    def __init__(self):
        rospy.init_node('navigation_node', anonymous=False)

        self.traverse_speed  = rospy.get_param('~traverse_speed',   0.08)
        self.obstacle_dist   = rospy.get_param('~obstacle_dist_m',  0.50)
        self.spray_duration  = rospy.get_param('~spray_duration_s', 0.50)
        self.row_spacing     = rospy.get_param('~row_spacing_m',    0.60)

        self._spray_flag  = False
        self._spray_lock  = threading.Lock()
        self._gps_lat     = None
        self._gps_lon     = None

        self._gpio = GPIOController()

        # ── Subscribers ───────────────────────────────────────────────────
        rospy.Subscriber('/spray/command', Bool, self._cb_spray, queue_size=1)
        if GPS_AVAILABLE:
            rospy.Subscriber('/gps/fix', NavSatFix, self._cb_gps, queue_size=1)

        # ── Publishers ────────────────────────────────────────────────────
        self.pub_cmd_vel = rospy.Publisher('/cmd_vel',       Twist,  queue_size=1)
        self.pub_status  = rospy.Publisher('/robot/status',  String, queue_size=1)

        rospy.on_shutdown(self._shutdown)
        rospy.loginfo("NavigationNode ready | speed=%.2f m/s", self.traverse_speed)

    # ── Callbacks ──────────────────────────────────────────────────────────────

    def _cb_spray(self, msg: Bool):
        with self._spray_lock:
            self._spray_flag = msg.data

    def _cb_gps(self, msg):
        self._gps_lat = msg.latitude
        self._gps_lon = msg.longitude

    # ── Obstacle detection ────────────────────────────────────────────────────

    def _check_obstacles(self) -> dict:
        distances = {}
        for direction in ULTRASONIC:
            distances[direction] = self._gpio.read_ultrasonic(direction)
        return distances

    def _obstacle_ahead(self) -> bool:
        dist = self._gpio.read_ultrasonic('front')
        blocked = dist < self.obstacle_dist
        if blocked:
            rospy.logwarn_throttle(1.0,
                "Obstacle detected at %.2f m (threshold=%.2f m). Stopping.",
                dist, self.obstacle_dist,
            )
        return blocked

    # ── Movement primitives ───────────────────────────────────────────────────

    def _move_forward(self):
        if not self._obstacle_ahead():
            self._gpio.set_motors(left_fwd=True, right_fwd=True)
            twist = Twist()
            twist.linear.x = self.traverse_speed
            self.pub_cmd_vel.publish(twist)
        else:
            self._stop()

    def _turn_right(self, duration_s: float = 1.2):
        self._gpio.set_motors(left_fwd=True, right_fwd=False)
        rospy.sleep(duration_s)
        self._stop()

    def _turn_left(self, duration_s: float = 1.2):
        self._gpio.set_motors(left_fwd=False, right_fwd=True)
        rospy.sleep(duration_s)
        self._stop()

    def _stop(self):
        self._gpio.stop_motors()
        self.pub_cmd_vel.publish(Twist())

    # ── Spray actuation ───────────────────────────────────────────────────────

    def _handle_spray(self):
        with self._spray_lock:
            should_spray = self._spray_flag
            self._spray_flag = False   # consume the flag

        if should_spray:
            self._stop()
            self._gpio.activate_sprayer(self.spray_duration)
            rospy.loginfo("Sprayer activated (%.2f s).", self.spray_duration)

    # ── Status publishing ─────────────────────────────────────────────────────

    def _publish_status(self, state: str):
        status = {
            'state':  state,
            'lat':    self._gps_lat,
            'lon':    self._gps_lon,
            'ts':     time.time(),
        }
        self.pub_status.publish(String(data=json.dumps(status)))

    # ── Main traversal loop ───────────────────────────────────────────────────

    def traverse_rows(self, n_rows: int = 25, row_length_m: float = 15.0):
        """
        Boustrophedon (snake) traversal of the field.

        Parameters
        ----------
        n_rows       : int    Number of tomato rows
        row_length_m : float  Length of each row in metres
        """
        step_duration = row_length_m / self.traverse_speed   # seconds per row
        rate = rospy.Rate(10)   # 10 Hz control loop

        rospy.loginfo(
            "Starting boustrophedon traversal: %d rows × %.1f m", n_rows, row_length_m
        )

        for row_idx in range(n_rows):
            if rospy.is_shutdown():
                break

            self._publish_status(f'traversing_row_{row_idx}')
            rospy.loginfo("Entering row %d / %d", row_idx + 1, n_rows)

            t_start = time.time()
            while (time.time() - t_start) < step_duration:
                if rospy.is_shutdown():
                    break
                self._move_forward()
                self._handle_spray()
                rate.sleep()

            self._stop()

            # End-of-row turn (alternating left/right for boustrophedon)
            if row_idx < n_rows - 1:
                self._publish_status(f'turning_after_row_{row_idx}')
                if row_idx % 2 == 0:
                    self._turn_right()
                    self._move_forward()
                    rospy.sleep(self.row_spacing / self.traverse_speed)
                    self._turn_right()
                else:
                    self._turn_left()
                    self._move_forward()
                    rospy.sleep(self.row_spacing / self.traverse_speed)
                    self._turn_left()
                self._stop()

        self._publish_status('traversal_complete')
        rospy.loginfo("Traversal complete.")

    def run(self):
        self.traverse_rows(
            n_rows=25,
            row_length_m=15.0,
        )
        rospy.spin()

    def _shutdown(self):
        self._stop()
        self._gpio.cleanup()
        rospy.loginfo("NavigationNode shut down cleanly.")


if __name__ == '__main__':
    try:
        node = NavigationNode()
        node.run()
    except rospy.ROSInterruptException:
        pass
