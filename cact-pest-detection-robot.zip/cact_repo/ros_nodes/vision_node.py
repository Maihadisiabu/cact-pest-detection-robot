#!/usr/bin/env python3
"""
vision_node.py
==============
ROS Melodic node: captures frames from the onboard camera, runs
MobileNetV2 inference on the Coral Edge TPU, and publishes the
softmax probability vector for each frame.

Subscriptions : none
Publications  :
    /pest_detection/probabilities  (std_msgs/Float32MultiArray)
        Four softmax probabilities: [p_whitefly, p_aphid, p_thrips, p_no_pest]
    /pest_detection/top_class      (std_msgs/String)
        Class name with highest probability (before CACT thresholding)

Parameters (ROS param server)
------------------------------
    ~model_path    : str   Path to _edgetpu.tflite model file
    ~camera_index  : int   OpenCV camera index (default: 0)
    ~capture_rate  : float Frames per second to capture (default: 3.0)
    ~image_width   : int   Capture width in pixels (default: 1280)
    ~image_height  : int   Capture height in pixels (default: 720)
"""

import sys
import time

import cv2
import numpy as np
import rospy
from std_msgs.msg import Float32MultiArray, MultiArrayDimension, String

# ── Inline inference (avoids circular import issues in ROS) ──────────────────
try:
    from pycoral.utils.edgetpu import make_interpreter
    from pycoral.adapters.common import set_input, output_tensor
    CORAL_AVAILABLE = True
except ImportError:
    CORAL_AVAILABLE = False
    rospy.logwarn("PyCoral not found — falling back to TFLite CPU inference.")

import tflite_runtime.interpreter as tflite
from PIL import Image

CLASS_NAMES = ['whitefly', 'aphid', 'thrips', 'no_pest']
INPUT_SIZE  = (224, 224)


class VisionNode:

    def __init__(self):
        rospy.init_node('vision_node', anonymous=False)

        model_path   = rospy.get_param('~model_path',   'models/mobilenetv2_tomato_pest_edgetpu.tflite')
        camera_index = rospy.get_param('~camera_index',  0)
        self.rate_hz = rospy.get_param('~capture_rate',  3.0)
        img_w        = rospy.get_param('~image_width',   1280)
        img_h        = rospy.get_param('~image_height',  720)

        # ── Publishers ────────────────────────────────────────────────────
        self.pub_probs = rospy.Publisher(
            '/pest_detection/probabilities',
            Float32MultiArray, queue_size=1,
        )
        self.pub_class = rospy.Publisher(
            '/pest_detection/top_class',
            String, queue_size=1,
        )

        # ── Camera ────────────────────────────────────────────────────────
        self.cap = cv2.VideoCapture(camera_index)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH,  img_w)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, img_h)
        self.cap.set(cv2.CAP_PROP_EXPOSURE, -6)   # manual exposure (darker = better for TPU latency)

        if not self.cap.isOpened():
            rospy.logerr("Failed to open camera index %d. Exiting.", camera_index)
            sys.exit(1)

        rospy.loginfo("Camera opened (index=%d, %dx%d).", camera_index, img_w, img_h)

        # ── Model ─────────────────────────────────────────────────────────
        self._load_model(model_path)
        rospy.loginfo("VisionNode ready | model=%s | rate=%.1f fps", model_path, self.rate_hz)

    # ── Model loading ──────────────────────────────────────────────────────────

    def _load_model(self, model_path: str):
        use_coral = CORAL_AVAILABLE and model_path.endswith('_edgetpu.tflite')
        if use_coral:
            self._interpreter = make_interpreter(model_path)
            self._interpreter.allocate_tensors()
            self._use_coral = True
            rospy.loginfo("Using Coral Edge TPU interpreter.")
        else:
            self._interpreter = tflite.Interpreter(model_path=model_path)
            self._interpreter.allocate_tensors()
            self._input_details  = self._interpreter.get_input_details()
            self._output_details = self._interpreter.get_output_details()
            self._use_coral = False
            rospy.loginfo("Using TFLite CPU interpreter.")

    # ── Inference ─────────────────────────────────────────────────────────────

    def _preprocess(self, frame: np.ndarray) -> np.ndarray:
        """Convert BGR OpenCV frame to normalised float32 model input."""
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        img = Image.fromarray(rgb).resize(INPUT_SIZE, Image.BILINEAR)
        arr = np.array(img, dtype=np.float32) / 255.0
        return np.expand_dims(arr, axis=0)

    def _infer(self, arr: np.ndarray) -> list:
        if self._use_coral:
            set_input(self._interpreter, arr)
            self._interpreter.invoke()
            output = output_tensor(self._interpreter, 0).flatten().tolist()
        else:
            self._interpreter.set_tensor(self._input_details[0]['index'], arr)
            self._interpreter.invoke()
            output = self._interpreter.get_tensor(
                self._output_details[0]['index']
            ).flatten().tolist()
        return output

    # ── Main loop ─────────────────────────────────────────────────────────────

    def run(self):
        rate = rospy.Rate(self.rate_hz)
        while not rospy.is_shutdown():
            ret, frame = self.cap.read()
            if not ret:
                rospy.logwarn_throttle(5.0, "Camera read failed — retrying.")
                rate.sleep()
                continue

            arr   = self._preprocess(frame)
            probs = self._infer(arr)

            # Publish probabilities
            msg = Float32MultiArray()
            msg.layout.dim = [
                MultiArrayDimension(
                    label='class', size=len(probs), stride=len(probs)
                )
            ]
            msg.data = probs
            self.pub_probs.publish(msg)

            # Publish top class name
            top_class = CLASS_NAMES[probs.index(max(probs))]
            self.pub_class.publish(String(data=top_class))

            rate.sleep()

        self.cap.release()
        rospy.loginfo("VisionNode shut down.")


if __name__ == '__main__':
    try:
        node = VisionNode()
        node.run()
    except rospy.ROSInterruptException:
        pass
