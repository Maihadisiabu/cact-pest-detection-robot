"""
augmentation.py
===============
On-the-fly data augmentation pipeline for MobileNetV2 training.

Augmentations are designed to simulate the lighting variation
encountered under tropical field conditions (morning dew, shadows,
evening backlighting, specular reflections).
"""

import tensorflow as tf


def build_augmentation_layer(
    brightness_delta: float = 0.3,
    contrast_range: tuple = (0.8, 1.2),
    rotation_factor: float = 0.055,   # ~20 degrees in [0,1] units
    flip_horizontal: bool = True,
    saturation_range: tuple = (0.8, 1.2),
    hue_delta: float = 0.05,
) -> tf.keras.Sequential:
    """
    Build a Keras preprocessing layer stack for training augmentation.

    Applied only during training (layer.trainable = True by default).
    All transforms are applied randomly and independently per image.

    Parameters
    ----------
    brightness_delta   : float   Max brightness shift (±delta)
    contrast_range     : tuple   (min, max) contrast scale factor
    rotation_factor    : float   Max rotation as fraction of 2π
    flip_horizontal    : bool    Randomly mirror horizontally
    saturation_range   : tuple   (min, max) saturation scale (HSV)
    hue_delta          : float   Max hue shift (±delta, range 0–0.5)

    Returns
    -------
    tf.keras.Sequential
        Augmentation pipeline to be called during training only.
    """
    layers = []

    if flip_horizontal:
        layers.append(tf.keras.layers.RandomFlip(mode='horizontal'))

    layers.append(
        tf.keras.layers.RandomRotation(
            factor=rotation_factor,
            fill_mode='reflect',
        )
    )
    layers.append(
        tf.keras.layers.RandomBrightness(factor=brightness_delta)
    )
    layers.append(
        tf.keras.layers.RandomContrast(factor=contrast_range[1] - 1.0)
    )

    return tf.keras.Sequential(layers, name='augmentation')


def augment_with_lambda(image: tf.Tensor) -> tf.Tensor:
    """
    Additional augmentations via Lambda ops (saturation, hue).
    Called inside tf.data.Dataset.map() for GPU-accelerated augmentation.

    Parameters
    ----------
    image : tf.Tensor  Float32 image tensor in [0, 1], shape (H, W, 3).

    Returns
    -------
    tf.Tensor  Augmented image, still in [0, 1].
    """
    # Random horizontal flip
    image = tf.image.random_flip_left_right(image)

    # Brightness / contrast (simulate lighting variation)
    image = tf.image.random_brightness(image, max_delta=0.3)
    image = tf.image.random_contrast(image, lower=0.8, upper=1.2)

    # Saturation / hue (simulate camera white-balance drift)
    image = tf.image.random_saturation(image, lower=0.8, upper=1.2)
    image = tf.image.random_hue(image, max_delta=0.05)

    # Clip to valid range
    image = tf.clip_by_value(image, 0.0, 1.0)
    return image
