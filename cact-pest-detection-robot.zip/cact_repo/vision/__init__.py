"""
vision — CNN training, inference, and augmentation modules.

Modules
-------
train_mobilenetv2  : Two-phase MobileNetV2 fine-tuning pipeline
inference_coral    : Coral Edge TPU / TFLite CPU inference wrapper
convert_to_tflite  : Post-training quantisation and TFLite export
augmentation       : Lighting-aware data augmentation pipeline
"""
