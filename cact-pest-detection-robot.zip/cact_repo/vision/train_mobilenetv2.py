"""
train_mobilenetv2.py
====================
Fine-tune MobileNetV2 on a custom tomato pest image dataset for use
with the CACT pest detection robot.

Reproduces the training procedure described in Section 3.4 of:
  Maihadisi, A. R. (2026). Context-Aware IoT-CNN Fusion for False-Positive
  Reduction in Edge-Based Agricultural Pest Detection.

Dataset structure expected
--------------------------
  data/
    train/
      whitefly/   *.jpg
      aphid/      *.jpg
      thrips/     *.jpg
      no_pest/    *.jpg
    val/
      (same structure)
    test/
      (same structure)

Usage
-----
python vision/train_mobilenetv2.py \
    --data-dir data/train/ \
    --val-dir  data/val/ \
    --output   models/mobilenetv2_tomato_pest.h5 \
    --epochs   60 \
    --batch    32 \
    --lr       1e-4

After training, convert to TFLite:
    python vision/convert_to_tflite.py \
        --model  models/mobilenetv2_tomato_pest.h5 \
        --output models/mobilenetv2_tomato_pest.tflite \
        --rep-data data/train/
"""

import argparse
import logging
import pathlib

import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, Model
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.callbacks import (
    EarlyStopping,
    ModelCheckpoint,
    ReduceLROnPlateau,
    TensorBoard,
)

from vision.augmentation import augment_with_lambda

logging.basicConfig(level=logging.INFO, format='%(levelname)s %(message)s')
logger = logging.getLogger(__name__)

# ── Constants ────────────────────────────────────────────────────────────────
CLASS_NAMES  = ['whitefly', 'aphid', 'thrips', 'no_pest']
NUM_CLASSES  = len(CLASS_NAMES)
INPUT_SIZE   = (224, 224)
INPUT_SHAPE  = (*INPUT_SIZE, 3)
SEED         = 42
AUTOTUNE     = tf.data.AUTOTUNE


# ── Dataset loading ───────────────────────────────────────────────────────────

def compute_class_weights(train_dir: str) -> dict:
    """
    Compute inverse-frequency class weights to address class imbalance.
    Upweights minority classes (thrips, aphid) relative to no_pest.

    Returns
    -------
    dict mapping class index → weight float
    """
    counts = {}
    root = pathlib.Path(train_dir)
    for idx, cls in enumerate(CLASS_NAMES):
        cls_dir = root / cls
        n = len(list(cls_dir.glob('*.jpg'))) + len(list(cls_dir.glob('*.png')))
        counts[idx] = max(n, 1)

    total   = sum(counts.values())
    weights = {
        idx: (total / (NUM_CLASSES * count))
        for idx, count in counts.items()
    }

    for idx, cls in enumerate(CLASS_NAMES):
        logger.info(
            "Class %-12s | n=%4d | weight=%.3f",
            cls, counts[idx], weights[idx],
        )
    return weights


def load_dataset(
    data_dir: str,
    batch_size: int,
    augment: bool = False,
    shuffle: bool = False,
) -> tf.data.Dataset:
    """
    Load a directory of class-labelled images into a tf.data.Dataset.

    Parameters
    ----------
    data_dir   : str   Root directory (class subdirectories)
    batch_size : int
    augment    : bool  Apply augmentation (training only)
    shuffle    : bool  Shuffle the dataset (training only)

    Returns
    -------
    tf.data.Dataset yielding (image_batch, label_batch)
    """
    dataset = tf.keras.utils.image_dataset_from_directory(
        data_dir,
        class_names=CLASS_NAMES,
        image_size=INPUT_SIZE,
        batch_size=batch_size,
        shuffle=shuffle,
        seed=SEED,
        label_mode='categorical',
    )

    # Normalise to [0, 1]
    normalise = layers.Rescaling(1.0 / 255)
    dataset   = dataset.map(
        lambda x, y: (normalise(x), y),
        num_parallel_calls=AUTOTUNE,
    )

    if augment:
        dataset = dataset.map(
            lambda x, y: (
                tf.map_fn(augment_with_lambda, x),
                y,
            ),
            num_parallel_calls=AUTOTUNE,
        )

    return dataset.prefetch(AUTOTUNE)


# ── Model ─────────────────────────────────────────────────────────────────────

def build_model(dropout_rate: float = 0.4) -> Model:
    """
    Build MobileNetV2 classifier with a custom head for NUM_CLASSES.

    Architecture
    ------------
    MobileNetV2 (ImageNet weights, frozen) →
    GlobalAveragePooling2D →
    Dense(128, relu) →
    Dropout(dropout_rate) →
    Dense(NUM_CLASSES, softmax)

    Transfer learning is done in two phases:
      Phase 1: Train head only (base frozen)
      Phase 2: Fine-tune top 30 layers of base (lower LR)

    Parameters
    ----------
    dropout_rate : float   Dropout rate for regularisation (default 0.4)

    Returns
    -------
    tf.keras.Model (compiled, base frozen)
    """
    base = MobileNetV2(
        input_shape=INPUT_SHAPE,
        include_top=False,
        weights='imagenet',
    )
    base.trainable = False

    inputs  = tf.keras.Input(shape=INPUT_SHAPE)
    x       = base(inputs, training=False)
    x       = layers.GlobalAveragePooling2D()(x)
    x       = layers.Dense(128, activation='relu')(x)
    x       = layers.Dropout(dropout_rate)(x)
    outputs = layers.Dense(NUM_CLASSES, activation='softmax')(x)

    model = Model(inputs, outputs, name='mobilenetv2_pest_classifier')
    return model


def unfreeze_top_layers(model: Model, n_layers: int = 30) -> None:
    """Unfreeze the top n_layers of the MobileNetV2 base for fine-tuning."""
    base = model.layers[1]   # MobileNetV2 base
    base.trainable = True
    for layer in base.layers[:-n_layers]:
        layer.trainable = False
    logger.info(
        "Unfroze top %d layers of MobileNetV2 base for fine-tuning.", n_layers
    )


# ── Training ──────────────────────────────────────────────────────────────────

def train(
    train_dir: str,
    val_dir: str,
    output_path: str,
    epochs: int = 60,
    batch_size: int = 32,
    learning_rate: float = 1e-4,
    fine_tune: bool = True,
    fine_tune_epochs: int = 20,
    fine_tune_lr: float = 1e-5,
    log_dir: str = 'logs/',
) -> None:
    """
    Full two-phase training pipeline.

    Phase 1 — Head training:
        Train the classifier head with the MobileNetV2 base frozen.

    Phase 2 — Fine-tuning (optional):
        Unfreeze the top 30 layers of MobileNetV2 and continue training
        at a lower learning rate.

    Parameters
    ----------
    train_dir         : str   Training image directory
    val_dir           : str   Validation image directory
    output_path       : str   Where to save the final .h5 model
    epochs            : int   Max epochs for phase 1
    batch_size        : int
    learning_rate     : float Phase 1 learning rate
    fine_tune         : bool  Whether to run phase 2
    fine_tune_epochs  : int   Additional epochs for phase 2
    fine_tune_lr      : float Phase 2 learning rate (should be << phase 1)
    log_dir           : str   TensorBoard log directory
    """
    tf.random.set_seed(SEED)
    np.random.seed(SEED)

    # ── Data ────────────────────────────────────────────────────────────
    logger.info("Loading training data from: %s", train_dir)
    train_ds = load_dataset(train_dir, batch_size, augment=True,  shuffle=True)
    val_ds   = load_dataset(val_dir,   batch_size, augment=False, shuffle=False)

    class_weights = compute_class_weights(train_dir)
    n_train = sum(1 for _ in train_ds.unbatch())
    n_val   = sum(1 for _ in val_ds.unbatch())
    logger.info("Training samples: %d | Validation samples: %d", n_train, n_val)

    # ── Phase 1: Head training ───────────────────────────────────────────
    logger.info("=== Phase 1: Training classifier head ===")
    model = build_model(dropout_rate=0.4)
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=learning_rate),
        loss='categorical_crossentropy',
        metrics=['accuracy'],
    )
    model.summary(print_fn=logger.info)

    output_path = pathlib.Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    best_model_path = str(output_path.with_suffix('.best.h5'))

    callbacks_phase1 = [
        EarlyStopping(
            monitor='val_loss', patience=10,
            restore_best_weights=True, verbose=1,
        ),
        ModelCheckpoint(
            best_model_path, monitor='val_accuracy',
            save_best_only=True, verbose=1,
        ),
        ReduceLROnPlateau(
            monitor='val_loss', factor=0.5,
            patience=5, min_lr=1e-7, verbose=1,
        ),
        TensorBoard(log_dir=str(pathlib.Path(log_dir) / 'phase1')),
    ]

    history1 = model.fit(
        train_ds,
        validation_data=val_ds,
        epochs=epochs,
        class_weight=class_weights,
        callbacks=callbacks_phase1,
        verbose=1,
    )

    phase1_best_val_acc = max(history1.history['val_accuracy'])
    logger.info("Phase 1 best val accuracy: %.4f", phase1_best_val_acc)

    # ── Phase 2: Fine-tuning ─────────────────────────────────────────────
    if fine_tune:
        logger.info("=== Phase 2: Fine-tuning top layers ===")
        unfreeze_top_layers(model, n_layers=30)
        model.compile(
            optimizer=tf.keras.optimizers.Adam(learning_rate=fine_tune_lr),
            loss='categorical_crossentropy',
            metrics=['accuracy'],
        )

        callbacks_phase2 = [
            EarlyStopping(
                monitor='val_loss', patience=10,
                restore_best_weights=True, verbose=1,
            ),
            ModelCheckpoint(
                best_model_path, monitor='val_accuracy',
                save_best_only=True, verbose=1,
            ),
            TensorBoard(log_dir=str(pathlib.Path(log_dir) / 'phase2')),
        ]

        history2 = model.fit(
            train_ds,
            validation_data=val_ds,
            epochs=fine_tune_epochs,
            class_weight=class_weights,
            callbacks=callbacks_phase2,
            verbose=1,
        )

        phase2_best_val_acc = max(history2.history['val_accuracy'])
        logger.info("Phase 2 best val accuracy: %.4f", phase2_best_val_acc)

    # ── Save final model ─────────────────────────────────────────────────
    model.save(str(output_path))
    logger.info("Final model saved to: %s", output_path)
    logger.info(
        "Next step — convert to TFLite:\n"
        "  python vision/convert_to_tflite.py "
        "--model %s --output %s --rep-data %s",
        output_path,
        output_path.with_name(output_path.stem + '.tflite'),
        train_dir,
    )


# ── CLI ───────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description='Fine-tune MobileNetV2 for tomato pest detection.'
    )
    parser.add_argument(
        '--data-dir', required=True,
        help='Training image directory (class subdirectories)'
    )
    parser.add_argument(
        '--val-dir', required=True,
        help='Validation image directory (class subdirectories)'
    )
    parser.add_argument(
        '--output', default='models/mobilenetv2_tomato_pest.h5',
        help='Output model path (.h5)'
    )
    parser.add_argument(
        '--epochs', type=int, default=60,
        help='Max epochs for phase 1 head training (default: 60)'
    )
    parser.add_argument(
        '--batch', type=int, default=32,
        help='Batch size (default: 32)'
    )
    parser.add_argument(
        '--lr', type=float, default=1e-4,
        help='Phase 1 learning rate (default: 1e-4)'
    )
    parser.add_argument(
        '--no-fine-tune', action='store_true',
        help='Skip phase 2 fine-tuning'
    )
    parser.add_argument(
        '--fine-tune-epochs', type=int, default=20,
        help='Phase 2 fine-tuning epochs (default: 20)'
    )
    parser.add_argument(
        '--fine-tune-lr', type=float, default=1e-5,
        help='Phase 2 learning rate (default: 1e-5)'
    )
    parser.add_argument(
        '--log-dir', default='logs/',
        help='TensorBoard log directory (default: logs/)'
    )
    args = parser.parse_args()

    train(
        train_dir        = args.data_dir,
        val_dir          = args.val_dir,
        output_path      = args.output,
        epochs           = args.epochs,
        batch_size       = args.batch,
        learning_rate    = args.lr,
        fine_tune        = not args.no_fine_tune,
        fine_tune_epochs = args.fine_tune_epochs,
        fine_tune_lr     = args.fine_tune_lr,
        log_dir          = args.log_dir,
    )


if __name__ == '__main__':
    main()
