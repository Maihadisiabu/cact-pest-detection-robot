"""
inference_coral.py
==================
On-device MobileNetV2 inference using the Google Coral Edge TPU.

Falls back to standard TFLite CPU inference if the Coral runtime
is not available (useful for development on a desktop machine).

Usage
-----
from vision.inference_coral import CoralInference

model = CoralInference("models/mobilenetv2_tomato_pest_edgetpu.tflite")
probs = model.predict("path/to/image.jpg")
# probs → list of 4 floats: [p_whitefly, p_aphid, p_thrips, p_no_pest]
"""

import logging
import time
from pathlib import Path
from typing import List, Optional

import numpy as np

logger = logging.getLogger(__name__)

# Input size expected by the model
INPUT_SIZE = (224, 224)
CLASS_NAMES = ['whitefly', 'aphid', 'thrips', 'no_pest']


class CoralInference:
    """
    Wraps a TFLite model compiled for the Google Coral Edge TPU.

    Parameters
    ----------
    model_path : str
        Path to a .tflite file. If the filename ends in '_edgetpu.tflite',
        the PyCoral runtime is used (requires Coral USB Accelerator).
        Otherwise standard TFLite CPU inference is used.

    class_names : list of str, optional
        Ordered class labels matching the model's softmax output.
    """

    def __init__(
        self,
        model_path: str,
        class_names: Optional[List[str]] = None,
    ):
        self.model_path  = str(model_path)
        self.class_names = class_names or CLASS_NAMES
        self._use_coral  = self.model_path.endswith('_edgetpu.tflite')

        if self._use_coral:
            self._load_coral()
        else:
            self._load_tflite_cpu()

        logger.info(
            "CoralInference ready | backend=%s | model=%s",
            "Coral Edge TPU" if self._use_coral else "TFLite CPU",
            Path(self.model_path).name,
        )

    # ------------------------------------------------------------------ #
    # Loading                                                              #
    # ------------------------------------------------------------------ #

    def _load_coral(self):
        try:
            from pycoral.utils.edgetpu import make_interpreter
            from pycoral.adapters.common import set_input
            self._set_input = set_input
            self._interpreter = make_interpreter(self.model_path)
            self._interpreter.allocate_tensors()
            logger.info("Coral Edge TPU interpreter loaded.")
        except ImportError:
            logger.warning(
                "PyCoral not installed or Coral device not found. "
                "Falling back to TFLite CPU inference."
            )
            self._use_coral = False
            self._load_tflite_cpu()

    def _load_tflite_cpu(self):
        import tflite_runtime.interpreter as tflite
        self._interpreter = tflite.Interpreter(model_path=self.model_path)
        self._interpreter.allocate_tensors()
        self._input_details  = self._interpreter.get_input_details()
        self._output_details = self._interpreter.get_output_details()
        logger.info("TFLite CPU interpreter loaded.")

    # ------------------------------------------------------------------ #
    # Inference                                                            #
    # ------------------------------------------------------------------ #

    def predict(self, image_path: str) -> List[float]:
        """
        Run inference on a single image file.

        Parameters
        ----------
        image_path : str
            Path to a JPEG or PNG image.

        Returns
        -------
        list of float
            Softmax probabilities, one per class in self.class_names order.
        """
        img_array = self._preprocess(image_path)
        return self._run_inference(img_array)

    def predict_array(self, img_array: np.ndarray) -> List[float]:
        """
        Run inference on a pre-processed NumPy array (H×W×C, uint8 or float32).
        """
        if img_array.ndim == 3:
            img_array = np.expand_dims(img_array, axis=0)
        return self._run_inference(img_array)

    # ------------------------------------------------------------------ #
    # Private helpers                                                      #
    # ------------------------------------------------------------------ #

    def _preprocess(self, image_path: str) -> np.ndarray:
        """Load, resize, and normalise an image for model input."""
        try:
            from PIL import Image
        except ImportError:
            raise ImportError("Pillow is required: pip install Pillow")

        img = Image.open(image_path).convert('RGB')
        img = img.resize(INPUT_SIZE, Image.BILINEAR)
        arr = np.array(img, dtype=np.float32) / 255.0
        return np.expand_dims(arr, axis=0)  # shape: (1, 224, 224, 3)

    def _run_inference(self, img_array: np.ndarray) -> List[float]:
        """Execute inference and return softmax probabilities."""
        t0 = time.perf_counter()

        if self._use_coral:
            from pycoral.adapters.common import set_input, output_tensor
            set_input(self._interpreter, img_array)
            self._interpreter.invoke()
            output = output_tensor(self._interpreter, 0)
        else:
            self._interpreter.set_tensor(
                self._input_details[0]['index'], img_array
            )
            self._interpreter.invoke()
            output = self._interpreter.get_tensor(
                self._output_details[0]['index']
            )

        latency_ms = (time.perf_counter() - t0) * 1000
        logger.debug("Inference latency: %.1f ms", latency_ms)

        probs = output.flatten().tolist()
        # Ensure output is a valid probability distribution
        total = sum(probs)
        if total > 0:
            probs = [p / total for p in probs]
        return probs

    # ------------------------------------------------------------------ #
    # Utilities                                                            #
    # ------------------------------------------------------------------ #

    def top_class(self, probs: List[float]) -> str:
        """Return the class name with the highest probability."""
        return self.class_names[probs.index(max(probs))]

    def benchmark(self, n_runs: int = 50) -> dict:
        """
        Measure average inference latency over n_runs dummy inferences.
        Useful for verifying Coral TPU acceleration on-device.

        Returns
        -------
        dict with keys 'mean_ms', 'std_ms', 'min_ms', 'max_ms'
        """
        dummy = np.random.rand(1, 224, 224, 3).astype(np.float32)
        latencies = []
        for _ in range(n_runs):
            t0 = time.perf_counter()
            self._run_inference(dummy)
            latencies.append((time.perf_counter() - t0) * 1000)
        latencies = np.array(latencies)
        result = {
            'mean_ms': round(float(latencies.mean()), 2),
            'std_ms':  round(float(latencies.std()),  2),
            'min_ms':  round(float(latencies.min()),  2),
            'max_ms':  round(float(latencies.max()),  2),
        }
        logger.info("Benchmark (%d runs): %s", n_runs, result)
        return result
