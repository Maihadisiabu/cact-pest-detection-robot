"""
convert_to_tflite.py
====================
Convert a trained Keras .h5 model to TFLite with full-integer
post-training quantisation, then compile for the Google Coral Edge TPU.

Usage
-----
# Step 1 — Convert to TFLite
python vision/convert_to_tflite.py \
    --model   models/mobilenetv2_tomato_pest.h5 \
    --output  models/mobilenetv2_tomato_pest.tflite \
    --rep-data data/train/

# Step 2 — Compile for Edge TPU (requires Edge TPU Compiler installed)
#   edgetpu_compiler models/mobilenetv2_tomato_pest.tflite -o models/
#   The compiler produces: mobilenetv2_tomato_pest_edgetpu.tflite

Notes
-----
- Full-integer quantisation maps all weights and activations to int8,
  enabling execution on the Coral Edge TPU.
- The representative dataset (~100–200 images) is used to calibrate
  activation ranges; it does not need to be the full training set.
- Edge TPU Compiler download: https://coral.ai/docs/edgetpu/compiler/
"""

import argparse
import logging
import pathlib
import random

import numpy as np
import tensorflow as tf

logging.basicConfig(level=logging.INFO, format='%(levelname)s %(message)s')
logger = logging.getLogger(__name__)

INPUT_SIZE   = (224, 224)
N_CALIB      = 150   # number of representative images for quantisation


def build_representative_dataset(rep_data_dir: str):
    """
    Generator that yields batches of representative images for
    post-training quantisation calibration.

    Parameters
    ----------
    rep_data_dir : str
        Root directory of training images (class subdirectories).
    """
    image_paths = list(pathlib.Path(rep_data_dir).rglob('*.jpg'))
    if not image_paths:
        image_paths = list(pathlib.Path(rep_data_dir).rglob('*.png'))

    if len(image_paths) == 0:
        raise FileNotFoundError(
            f"No images found in representative dataset directory: {rep_data_dir}"
        )

    # Sample randomly if more images than needed
    if len(image_paths) > N_CALIB:
        image_paths = random.sample(image_paths, N_CALIB)

    logger.info(
        "Using %d images for quantisation calibration.", len(image_paths)
    )

    def _generator():
        for path in image_paths:
            img = tf.keras.utils.load_img(path, target_size=INPUT_SIZE)
            arr = tf.keras.utils.img_to_array(img) / 255.0
            arr = np.expand_dims(arr, axis=0).astype(np.float32)
            yield [arr]

    return _generator


def convert(model_path: str, output_path: str, rep_data_dir: str) -> None:
    """
    Load a Keras model and convert it to full-integer quantised TFLite.

    Parameters
    ----------
    model_path   : str   Path to .h5 or SavedModel directory.
    output_path  : str   Destination .tflite file path.
    rep_data_dir : str   Directory of representative calibration images.
    """
    logger.info("Loading model from: %s", model_path)
    model = tf.keras.models.load_model(model_path)
    model.summary(print_fn=logger.info)

    logger.info("Building TFLite converter...")
    converter = tf.lite.TFLiteConverter.from_keras_model(model)

    # Full-integer post-training quantisation (required for Edge TPU)
    converter.optimizations = [tf.lite.Optimize.DEFAULT]
    converter.representative_dataset = build_representative_dataset(rep_data_dir)
    converter.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS_INT8]
    converter.inference_input_type  = tf.uint8
    converter.inference_output_type = tf.uint8

    logger.info("Running conversion (this may take a minute)...")
    tflite_model = converter.convert()

    output_path = pathlib.Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_bytes(tflite_model)

    size_mb = output_path.stat().st_size / (1024 ** 2)
    logger.info("TFLite model saved to: %s (%.2f MB)", output_path, size_mb)
    logger.info(
        "Next step: compile for Edge TPU with:\n"
        "  edgetpu_compiler %s -o %s",
        output_path, output_path.parent,
    )


def main():
    parser = argparse.ArgumentParser(
        description='Convert Keras model to quantised TFLite for Coral Edge TPU.'
    )
    parser.add_argument(
        '--model',    required=True,
        help='Path to trained Keras model (.h5 or SavedModel dir)'
    )
    parser.add_argument(
        '--output',   required=True,
        help='Output .tflite file path'
    )
    parser.add_argument(
        '--rep-data', required=True, dest='rep_data',
        help='Directory of representative calibration images (class subdirs)'
    )
    args = parser.parse_args()
    convert(args.model, args.output, args.rep_data)


if __name__ == '__main__':
    main()
